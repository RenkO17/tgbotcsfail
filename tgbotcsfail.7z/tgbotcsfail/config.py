TOKEN = '1318152632:AAEXJmbomT143xDilK_kGiegt1_-qWxY9lU'    # что за бот

# для получения данных по апи
headers = {'accept-language': 'en-US,en;q=0.9,ru;q=0.8',
           'content-type': 'text/plain',
           'origin': 'https://cs.fail',
           'sec-fetch-dest': 'empty',
           'sec-fetch-mode': 'cors',
           'sec-fetch-site': 'same-site',
           'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36',}

# orderer = '1259686452'  # ид куда идёт информация
orderer = '-1001368915580'  # ид куда идёт информация
